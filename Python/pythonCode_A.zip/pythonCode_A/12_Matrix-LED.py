# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
from time import sleep

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

#Define the pin of the row
row1 = 27
row2 = 4
row3 = 5
row4 = 17
row5 = 26
row6 = 6
row7 = 19
row8 = 13
#Define the pins of the column
col1 = 24
col2 = 16
col3 = 20
col4 = 18
col5 = 21
col6 = 23
col7 = 25
col8 = 12

#Set to output
GPIO.setup(row1,GPIO.OUT)
GPIO.setup(row2,GPIO.OUT)
GPIO.setup(row3,GPIO.OUT)
GPIO.setup(row4,GPIO.OUT)
GPIO.setup(row5,GPIO.OUT)
GPIO.setup(row6,GPIO.OUT)
GPIO.setup(row7,GPIO.OUT)
GPIO.setup(row8,GPIO.OUT)

GPIO.setup(col1,GPIO.OUT)
GPIO.setup(col2,GPIO.OUT)
GPIO.setup(col3,GPIO.OUT)
GPIO.setup(col4,GPIO.OUT)
GPIO.setup(col5,GPIO.OUT)
GPIO.setup(col6,GPIO.OUT)
GPIO.setup(col7,GPIO.OUT)
GPIO.setup(col8,GPIO.OUT)

#Sets the pin of the column to low level
GPIO.output(col1,GPIO.LOW)
GPIO.output(col2,GPIO.LOW)
GPIO.output(col3,GPIO.LOW)
GPIO.output(col4,GPIO.LOW)
GPIO.output(col5,GPIO.LOW)
GPIO.output(col6,GPIO.LOW)
GPIO.output(col7,GPIO.LOW)
GPIO.output(col8,GPIO.LOW)

#Since the column of the lattice has been set to low level, 
#the corresponding row of the lattice will light up when the pin of the row is at high level
def Row(d):
    if(d ==1):
        GPIO.output(row1,GPIO.HIGH)  #Light the first line
    if(d ==2):
        GPIO.output(row2,GPIO.HIGH)  #Light the second line
    if(d ==3):
        GPIO.output(row3,GPIO.HIGH)
    if(d ==4):
        GPIO.output(row4,GPIO.HIGH)
    if(d ==5):
        GPIO.output(row5,GPIO.HIGH)
    if(d ==6):
        GPIO.output(row6,GPIO.HIGH)
    if(d ==7):
        GPIO.output(row7,GPIO.HIGH)
    if(d ==8):
        GPIO.output(row8,GPIO.HIGH)
    
#Close the lattice
def off(): 
    GPIO.output(row1,GPIO.LOW)
    GPIO.output(row2,GPIO.LOW)
    GPIO.output(row3,GPIO.LOW)
    GPIO.output(row4,GPIO.LOW)
    GPIO.output(row5,GPIO.LOW)
    GPIO.output(row6,GPIO.LOW)
    GPIO.output(row7,GPIO.LOW)
    GPIO.output(row8,GPIO.LOW)

print("test...")
while True:
    for num in range(1,10):  #Light the lattice line by line
        Row(num)
        if(num == 9):  #Because the lattice has only 8 rows, and I'm limiting it here, is equal to 9
            off()      #Close the lattice
        sleep(0.2)

GPIO.cleanup()  #Release all GPIO ports
