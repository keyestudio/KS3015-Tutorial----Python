import time
import RPi.GPIO as GPIO

servo_min_angle = 2.5  #define pulse duty cycle for minimun angle of servo
servo_max_angle = 12.5  #define pulse duty cycle for maximun angle of servo
servopin = 18   #servo Pin
GPIO.setmode(GPIO.BCM)  #BCM numbers
GPIO.setup(servopin,GPIO.OUT)
p = GPIO.PWM(servopin,50)  #set 50Hz , The working frequency of the steering gear is 50Hz
p.start(0)  # start PWM
time.sleep(1)

#define function, map a value from one range to another range
def map(angle, val1, val2, min_angle, max_angle):
    return (max_angle-min_angle)*(angle-val1)/(val2-val1)+min_angle
    
p.ChangeDutyCycle(0)   #set 
time.sleep(0.5)


class keypad(object):
  KEYPAD=[
    ['1','2','3','A'],
    ['4','5','6','B'],
    ['7','8','9','C'],
    ['*','0','#','D']]
 
  ROW    =[12,16,20,21]#row
  COLUMN =[6,13,19,26]#col
 
#init function
def __init__():
  GPIO.cleanup()
  GPIO.setmode(GPIO.BCM)

#Get the number of keys
def getkey():
  GPIO.setmode(GPIO.BCM)
  #Set the column output low
  for i in range(len(keypad.COLUMN)):
    GPIO.setup(keypad.COLUMN[i],GPIO.OUT)
    GPIO.output(keypad.COLUMN[i],GPIO.LOW)
  #Set the row input and pull up
  for j in range(len(keypad.ROW)):
    GPIO.setup(keypad.ROW[j],GPIO.IN,pull_up_down=GPIO.PUD_UP)
 
  #Detects if a row has a key pressed down and reads the row value if so
  RowVal=-1
  for i in range(len(keypad.ROW)):
    RowStatus=GPIO.input(keypad.ROW[i])
    if RowStatus==GPIO.LOW:
       RowVal=i
       #print('RowVal=%s' % RowVal)
  #If no key is pressed, exit to prepare for the next scan
  if RowVal<0 or RowVal>3:
    exit()
    return
 
  #If row RowVal has a key pressed down
  #Outputs a high level row RowVal
  GPIO.setup(keypad.ROW[RowVal],GPIO.OUT)
  GPIO.output(keypad.ROW[RowVal],GPIO.HIGH)
  #Column drop-down input
  for j in range(len(keypad.COLUMN)):
    GPIO.setup(keypad.COLUMN[j],GPIO.IN,pull_up_down=GPIO.PUD_DOWN)
 
  #Read the value of the column in which the key resides
  ColumnVal=-1
  for i in range(len(keypad.COLUMN)):
    ColumnStatus=GPIO.input(keypad.COLUMN[i])
    if ColumnStatus==GPIO.HIGH:
      ColumnVal=i
      #Wait for the button to release
      while GPIO.input(keypad.COLUMN[i])==GPIO.HIGH:
        time.sleep(0.05)
        #print ('ColumnVal=%s' % ColumnVal)
  #If no key is pressed, return
  if ColumnVal<0 or ColumnVal>3:
    exit()
    return
 
  exit()
  return keypad.KEYPAD[RowVal][ColumnVal] #return keypad value
 
 
def exit():
  import RPi.GPIO as GPIO
  for i in range(len(keypad.ROW)):
    GPIO.setup( keypad.ROW[i],GPIO.IN,pull_up_down=GPIO.PUD_UP)
  for j in range(len( keypad.COLUMN)):
    GPIO.setup( keypad.COLUMN[j],GPIO.IN,pull_up_down=GPIO.PUD_UP)
 
print('Please enter your password : ')
#key=None
passward = ''
while True:
    key=getkey()  #Assigns the detected keyboard value to key
    if not key==None:  #If the key value is not null
        print (key)  #Displays the password entered
        passward = passward + key
        if(key == 'D'):
          print (passward)  #passward
          if(passward == "123D"): #set the password here
            print("open the door")
            p.ChangeDutyCycle(12.5)
            time.sleep(0.5)
            passward = ''
          else:
            print("error")
            p.ChangeDutyCycle(2.5)
            time.sleep(0.5)
            passward = ''
        
p.stop()
GPIO.cleanup()
