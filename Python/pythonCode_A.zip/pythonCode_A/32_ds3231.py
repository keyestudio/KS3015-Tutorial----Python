#-*- coding: UTF-8 -*-
import RPi.GPIO as GPIO
import smbus   
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)

addr_ds3231 = 0x68 ##address  ---> device address
addr_second = 0x00
addr_minute = 0x01
addr_hour = 0x02
addr_week = 0x03
addr_data = 0x04
addr_month = 0x05
addr_year = 0x06

dat = []  # Defines a list that stores the time it was read

def set_time():
    bus.write_byte_data(addr_ds3231,addr_year,0x20)  ##20
    bus.write_byte_data(addr_ds3231,addr_month,0x03) ##March
    bus.write_byte_data(addr_ds3231,addr_data,0x26)  ##date 26 
    bus.write_byte_data(addr_ds3231,addr_week,0x04)  ##Thursday
    bus.write_byte_data(addr_ds3231,addr_hour,0x12)  ##24 hour mode,12 o'clock
    bus.write_byte_data(addr_ds3231,addr_minute,0x30)
    bus.write_byte_data(addr_ds3231,addr_second,0x00)

def read_time():
    second = bus.read_byte_data(addr_ds3231,addr_second)  #The seconds read are assigned to the variable second
    minute = bus.read_byte_data(addr_ds3231,addr_minute)
    hour = bus.read_byte_data(addr_ds3231,addr_hour)
    week = bus.read_byte_data(addr_ds3231,addr_week) 
    data = bus.read_byte_data(addr_ds3231,addr_data) 
    month = bus.read_byte_data(addr_ds3231,addr_month)
    year = bus.read_byte_data(addr_ds3231,addr_year) 
    # .append , Add an element to the end of the list
    dat.append(year/16*10 + year%16 + 2000)   #To calculate the years, 0x20 to 20
    dat.append(month/16*10 + month%16)
    dat.append(data/16*10 + data%16)
    dat.append(week)
    dat.append(hour/16*10 + hour%16) 
    dat.append(minute/16*10 + minute%16)
    dat.append(second/16*10 + second%16)
    
bus = smbus.SMBus(1)             #Create an instance of smbus
set_time()
while True:                      ##loop 
    read_time()
    print "date: year  month  date  week  hour  minute  second"
    print "date:",dat            ##print data
    dat = []  #Clear the array DAT to 0
    time.sleep(1)                ##delay 1 second
