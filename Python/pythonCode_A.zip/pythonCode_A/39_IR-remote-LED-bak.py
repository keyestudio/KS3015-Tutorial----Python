#!/usr/bin/python
# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import time

ERROR = 0xFE
PIN = 24  #红外接收模块的引脚

ledPin = 25  #define led pin
 
GPIO.setmode(GPIO.BCM)  #BCM numbers
GPIO.setwarnings(False)
GPIO.setup(PIN, GPIO.IN, GPIO.PUD_UP)  #将红外接收引脚设置为高电平
GPIO.setup(ledPin,GPIO.OUT)   #set the ledPin OUTPUT mode
GPIO.output(ledPin,GPIO.LOW)  # make ledPin output LOW level

def getKey():
    byte = [0, 0, 0, 0]  #总共有4个字节，第一个字节是地址码，第二个是地址反码，第三个是对应按钮的控制命令数据，第四个是控制命令反码
    if IRStart() == False:  #引导码错误时，执行下面的程序
        time.sleep(0.11)        # One message frame lasts 108 ms.
        return ERROR
    else:    #引导码正确时，就继续分析32位数据，分为4个字节来接收
        for i in range(0, 4):  #4个字节，一个一个的接收
                byte[i] = getByte()
        #判断是否 地址码+地址反码=0xff，  控制码+控制反码=0xff
        if byte[0] + byte[1] == 0xff and byte[2] + byte[3] == 0xff:
            return byte[2]  #将控制码返回
        else:  #否则返回ERROR ， ERROR = 0xFE
            return ERROR   

#红外接收，NEC协议的引导码
#9ms的低电平，4.5ms的高电平
def IRStart():
    timeFallingEdge = [0, 0]  #定义数组变量，用于储存，引脚为下降沿时的时间
    timeRisingEdge = 0  #变量，储存引脚为上升沿时的时间
    timeSpan = [0, 0]  #用储存时间间隔
    GPIO.wait_for_edge(PIN, GPIO.FALLING)  #初始化时，已经将引脚设置为高，这里等待出现下降沿，出现下降沿，程序才会往下走
    timeFallingEdge[0] = time.time()  #程序运行到这的时间值赋给timeFallingEdge[0]
    GPIO.wait_for_edge(PIN, GPIO.RISING) #等待上升沿
    timeRisingEdge = time.time() #程序运行到这的时间值赋给timeRisingEdge
    GPIO.wait_for_edge(PIN, GPIO.FALLING) #等待下降沿
    timeFallingEdge[1] = time.time() #程序运行到这的时间值赋给timeFallingEdge[1]
    timeSpan[0] = timeRisingEdge - timeFallingEdge[0] #从第一个下降沿到上升沿的时间间隔，正确的是9ms
    timeSpan[1] = timeFallingEdge[1] - timeRisingEdge #从上升沿到第二个下降沿的时间间隔，正确的是4.5ms
    #判断如果时间符合NEC协议的引导码时间，那就返回True，否则为False
    if (timeSpan[0] > 0.0085 and  timeSpan[0] < 0.0095) and (timeSpan[1] > 0.004 and  timeSpan[1] < 0.005):
        return True
    else:
        return False


def getByte():  #获取每个字节的每一位的数据
    byte = 0
    timeRisingEdge = 0  
    timeFallingEdge = 0
    timeSpan = 0
    for i in range(0, 8):  #每个字节有8位，通过周期的长短判断接收到的是1还是0
        GPIO.wait_for_edge(PIN, GPIO.RISING) #等待上升沿
        timeRisingEdge = time.time() #程序运行到这的时间值赋给timeRisingEdge
        GPIO.wait_for_edge(PIN, GPIO.FALLING)  #等待上升沿
        timeFallingEdge = time.time()  #程序运行到这的时间值赋给timeFallingEdge
        timeSpan = timeFallingEdge - timeRisingEdge  #这里就是接收数据是的高电平时的时间值
        if timeSpan > 0.0016 and timeSpan < 0.0018:   #根据NEC协议2.25ms-0.5625就是在0.0016s~0.0018s的范围内，就是返回1，否则为0
            byte |= 1 << i  #等效于 byte = byte | (1 << i)  ,就是把对应数据的高低电平传到字节中（一个字节有8位)
        else:
            byte |= 0 << i
    return byte

print('IRM Test Start ...')
try:
    while True:  #程序从这里开始，进入循环
        key = getKey() #调用函数getKey()
        if(key != ERROR):
            print("Get the key: 0x%02x" %key)  #将接收到的按键值在终端打印出来
            if(key == 0x46):
                GPIO.output(ledPin,GPIO.HIGH)  #turn on led
                print("turn on led")
            if(key == 0x40):
                GPIO.output(ledPin,GPIO.LOW)  #turn off led
                print("turn on led")
                                
except KeyboardInterrupt:  #按Ctrl + Z 退出终端打印
    GPIO.cleanup()
