#!/usr/bin/python
# -*- coding:utf-8 -*-
import RPi.GPIO as GPIO
import time

ERROR = 0xFE
PIN = 24  #红外接收模块的引脚

pin_R = 21
pin_G = 20
pin_B = 16

relayPin = 12   #define relay pin

#define L293D pin
INA1 = 17
INA2 = 27
ENA = 22
global speed
speed = 60

GPIO.setmode(GPIO.BCM)  #BCM numbers
GPIO.setwarnings(False)
GPIO.setup(PIN, GPIO.IN, GPIO.PUD_UP)  #将红外接收引脚设置为高电平

#set the RGB Pin OUTPUT mode
GPIO.setup(pin_R,GPIO.OUT)
GPIO.setup(pin_G,GPIO.OUT)
GPIO.setup(pin_B,GPIO.OUT)
#set pwm frequence to 1000hz
pwm_R = GPIO.PWM(pin_R,100)
pwm_G = GPIO.PWM(pin_G,100)
pwm_B = GPIO.PWM(pin_B,100)
#set inital duty cycle to 0
pwm_R.start(0)
pwm_G.start(0)
pwm_B.start(0)

GPIO.setup(relayPin,GPIO.OUT)
GPIO.output(relayPin,GPIO.LOW)

servo_min_angle = 2.5  #define pulse duty cycle for minimun angle of servo
servo_max_angle = 12.5  #define pulse duty cycle for maximun angle of servo
servopin = 26   #servo Pin
GPIO.setup(servopin,GPIO.OUT)
p = GPIO.PWM(servopin,50)  #set 50Hz , The working frequency of the steering gear is 50Hz
p.start(0)  # start PWM
global angle
angle = 0
time.sleep(0.5)

GPIO.setup(INA1,GPIO.OUT)
GPIO.setup(INA2,GPIO.OUT)
GPIO.setup(ENA,GPIO.OUT)
pwmA = GPIO.PWM(ENA,100)  #create a PWM instance
pwmA.start(0)   #start PWM

def getKey():
    byte = [0, 0, 0, 0]  #总共有4个字节，第一个字节是地址码，第二个是地址反码，第三个是对应按钮的控制命令数据，第四个是控制命令反码
    if IRStart() == False:  #引导码错误时，执行下面的程序
        time.sleep(0.11)        # One message frame lasts 108 ms.
        return ERROR
    else:    #引导码正确时，就继续分析32位数据，分为4个字节来接收
        for i in range(0, 4):  #4个字节，一个一个的接收
                byte[i] = getByte()
        #判断是否 地址码+地址反码=0xff，  控制码+控制反码=0xff
        if byte[0] + byte[1] == 0xff and byte[2] + byte[3] == 0xff:
            return byte[2]  #将控制码返回
        else:  #否则返回ERROR ， ERROR = 0xFE
            return ERROR   

#红外接收，NEC协议的引导码
#9ms的低电平，4.5ms的高电平
def IRStart():
    timeFallingEdge = [0, 0]  #定义数组变量，用于储存，引脚为下降沿时的时间
    timeRisingEdge = 0  #变量，储存引脚为上升沿时的时间
    timeSpan = [0, 0]  #用储存时间间隔
    GPIO.wait_for_edge(PIN, GPIO.FALLING)  #初始化时，已经将引脚设置为高，这里等待出现下降沿，出现下降沿，程序才会往下走
    timeFallingEdge[0] = time.time()  #程序运行到这的时间值赋给timeFallingEdge[0]
    GPIO.wait_for_edge(PIN, GPIO.RISING) #等待上升沿
    timeRisingEdge = time.time() #程序运行到这的时间值赋给timeRisingEdge
    GPIO.wait_for_edge(PIN, GPIO.FALLING) #等待下降沿
    timeFallingEdge[1] = time.time() #程序运行到这的时间值赋给timeFallingEdge[1]
    timeSpan[0] = timeRisingEdge - timeFallingEdge[0] #从第一个下降沿到上升沿的时间间隔，正确的是9ms
    timeSpan[1] = timeFallingEdge[1] - timeRisingEdge #从上升沿到第二个下降沿的时间间隔，正确的是4.5ms
    #判断如果时间符合NEC协议的引导码时间，那就返回True，否则为False
    if (timeSpan[0] > 0.0085 and  timeSpan[0] < 0.0095) and (timeSpan[1] > 0.004 and  timeSpan[1] < 0.005):
        return True
    else:
        return False


def getByte():  #获取每个字节的每一位的数据
    byte = 0
    timeRisingEdge = 0  
    timeFallingEdge = 0
    timeSpan = 0
    for i in range(0, 8):  #每个字节有8位，通过周期的长短判断接收到的是1还是0
        GPIO.wait_for_edge(PIN, GPIO.RISING) #等待上升沿
        timeRisingEdge = time.time() #程序运行到这的时间值赋给timeRisingEdge
        GPIO.wait_for_edge(PIN, GPIO.FALLING)  #等待上升沿
        timeFallingEdge = time.time()  #程序运行到这的时间值赋给timeFallingEdge
        timeSpan = timeFallingEdge - timeRisingEdge  #这里就是接收数据是的高电平时的时间值
        if timeSpan > 0.0016 and timeSpan < 0.0018:   #根据NEC协议2.25ms-0.5625就是在0.0016s~0.0018s的范围内，就是返回1，否则为0
            byte |= 1 << i  #等效于 byte = byte | (1 << i)  ,就是把对应数据的高低电平传到字节中（一个字节有8位)
        else:
            byte |= 0 << i
    return byte


def forward():
    GPIO.output(INA1,GPIO.HIGH)
    GPIO.output(INA2,GPIO.LOW)
    pwmA.ChangeDutyCycle(speed)
    
def back():
    GPIO.output(INA1,GPIO.LOW)
    GPIO.output(INA2,GPIO.HIGH)
    pwmA.ChangeDutyCycle(speed)
    
def stop():
    pwmA.ChangeDutyCycle(0)
    
#function. receive the value to display different colors
def setColor(val_R,val_G,val_B):
    pwm_R.ChangeDutyCycle(val_R)
    pwm_G.ChangeDutyCycle(val_G)
    pwm_B.ChangeDutyCycle(val_B)
    
#define function, map a value from one range to another range
def map(angle, val1, val2, min_angle, max_angle):
    return (max_angle-min_angle)*(angle-val1)/(val2-val1)+min_angle
    
    
print('IRM Test Start ...')
try:
    while True:  #程序从这里开始，进入循环
        
        key = getKey() #调用函数getKey()
        if(key != ERROR):
            print("Get the key: 0x%02x" %key)  #将接收到的按键值在终端打印出来
            
            if(key == 0x44):
                forward()
                print("motor run")
            if(key == 0x43):
                back()
                print("motor back")
            if(key == 0x40):
                stop()
                print("motor stop")
            if(key == 0x46):
                speed = speed + 10
                if(speed >= 100):
                    speed = 100
                print("speed add 10")
            if(key == 0x15):
                speed = speed - 10
                if(speed <= 50):
                    speed = 50
                print("speed subtract 10")
                
            if(key == 0x16):
                setColor(100,0,0)
            if(key == 0x19):
                setColor(0,100,0)
            if(key == 0x0d):
                setColor(0,0,100)
            if(key == 0x0c):
                setColor(100,100,0)
            if(key == 0x18):
                setColor(0,100,100)
            if(key == 0x5e):
                setColor(100,100,100)
            if(key == 0x1c):
                setColor(0,0,0)
            
            if(key == 0x08):
                GPIO.output(relayPin,GPIO.HIGH)  #Starting relay
            if(key == 0x5a):
                GPIO.output(relayPin,GPIO.LOW)
            if(key == 0x42):
                p.ChangeDutyCycle(0)
                angle = angle + 10
                if(angle >= 180):
                    angle = 180
                c = map(angle, 0, 180, servo_min_angle, servo_max_angle)  #map angle from 0~180 to 2.5~12.5
                p.ChangeDutyCycle(c) 
                time.sleep(0.01)
            if(key == 0x4a):
                p.ChangeDutyCycle(0)
                angle = angle - 10
                if(angle <= 0):
                    angle = 0
                c = map(angle, 0, 180, servo_min_angle, servo_max_angle)  #map angle from 0~180 to 2.5~12.5
                p.ChangeDutyCycle(c) 
                time.sleep(0.01)
            
                                
except KeyboardInterrupt:  #按Ctrl + Z 退出终端打印
    GPIO.cleanup()
