import RPi.GPIO as GPIO
import time

PIN = 24;  #Infrared receiving pin

GPIO.setmode(GPIO.BCM)

GPIO.setup(PIN,GPIO.IN,GPIO.PUD_UP)

ledPin = 25  #define led pin
GPIO.setup(ledPin,GPIO.OUT)   #set the ledPin OUTPUT mode
GPIO.output(ledPin,GPIO.LOW)  # make ledPin output LOW level
#define RGB pin
pin_R = 21
pin_G = 20
pin_B = 16

relayPin = 12   #define relay pin

#define L293D pin
INA1 = 17
INA2 = 27
ENA = 22
global speed
speed = 60

#set the RGB Pin OUTPUT mode
GPIO.setup(pin_R,GPIO.OUT)
GPIO.setup(pin_G,GPIO.OUT)
GPIO.setup(pin_B,GPIO.OUT)
#set pwm frequence to 1000hz
pwm_R = GPIO.PWM(pin_R,100)
pwm_G = GPIO.PWM(pin_G,100)
pwm_B = GPIO.PWM(pin_B,100)
#set inital duty cycle to 0
pwm_R.start(0)
pwm_G.start(0)
pwm_B.start(0)

GPIO.setup(relayPin,GPIO.OUT)
GPIO.output(relayPin,GPIO.LOW)

servo_min_angle = 2.5  #define pulse duty cycle for minimun angle of servo
servo_max_angle = 12.5  #define pulse duty cycle for maximun angle of servo
servopin = 26   #servo Pin
GPIO.setup(servopin,GPIO.OUT)
p = GPIO.PWM(servopin,50)  #set 50Hz , The working frequency of the steering gear is 50Hz
p.start(0)  # start PWM
global angle
angle = 0
time.sleep(0.5)

GPIO.setup(INA1,GPIO.OUT)
GPIO.setup(INA2,GPIO.OUT)
GPIO.setup(ENA,GPIO.OUT)
pwmA = GPIO.PWM(ENA,100)  #create a PWM instance
pwmA.start(0)   #start PWM

print("irm test start...")

#motor forward
def forward():
    GPIO.output(INA1,GPIO.HIGH)
    GPIO.output(INA2,GPIO.LOW)
    pwmA.ChangeDutyCycle(speed)
    
def back():
    GPIO.output(INA1,GPIO.LOW)
    GPIO.output(INA2,GPIO.HIGH)
    pwmA.ChangeDutyCycle(speed)
    
def stop():
    pwmA.ChangeDutyCycle(0)
    
#function. receive the value to display different colors
def setColor(val_R,val_G,val_B):
    pwm_R.ChangeDutyCycle(val_R)
    pwm_G.ChangeDutyCycle(val_G)
    pwm_B.ChangeDutyCycle(val_B)
    
#define function, map a value from one range to another range
def map(angle, val1, val2, min_angle, max_angle):
    return (max_angle-min_angle)*(angle-val1)/(val2-val1)+min_angle


def exec_cmd(key_val):
    if(key_val==0x46):
        print("Button up")
    elif(key_val==0x44):
        print("Button left")
    elif(key_val==0x40):
        print("Button ok")
    elif(key_val==0x43):
        print("Button right")
    elif(key_val==0x15):
        print("Button down")
    elif(key_val==0x16):
        print("Button 1")
    elif(key_val==0x19):
        print("Button 2")
    elif(key_val==0x0d):
        print("Button 3")
    elif(key_val==0x0c):
        print("Button 4")
    elif(key_val==0x18):
        print("Button 5")
    elif(key_val==0x5e):
        print("Button 6")
    elif(key_val==0x08):
        print("Button 7")
    elif(key_val==0x1c):
        print("Button 8")
    elif(key_val==0x5a):
        print("Button 9")
    elif(key_val==0x42):
        print("Button *")
    elif(key_val==0x52):
        print("Button 0")
    elif(key_val==0x4a):
        print("Button #")

try:
    while True:
        if GPIO.input(PIN) == 0:
            count = 0
            while GPIO.input(PIN) == 0 and count < 200:  # Wait for 9ms LOW level boot code and exit the loop if it exceeds 1.2ms
                count += 1
                time.sleep(0.00006)

            count = 0
            while GPIO.input(PIN) == 1 and count < 80:   # Wait for a 4.5ms HIGH level boot code and exit the loop if it exceeds 0.48ms
                count += 1
                time.sleep(0.00006)

            idx = 0  # byte count variable
            cnt = 0  #Variable per byte bit
            #There are 4 bytes in total. The first byte is the address code, the second is the address inverse code, 
            #the third is the control command data of the corresponding button, and the fourth is the control command inverse code
            data = [0,0,0,0]
            for i in range(0,32):  # Start receiving 32BITE data
                count = 0
                while GPIO.input(PIN) == 0 and count < 15:  # Wait for the LOW LOW level of 562.5US to pass and exit the loop if it exceeds 900US
                    count += 1
                    time.sleep(0.00006)

                count = 0
                while GPIO.input(PIN) == 1 and count < 40:  # waits for logical HIGH level to pass and exits the loop if it exceeds 2.4ms
                    count += 1
                    time.sleep(0.00006)
                
                # if count>8, that is, the logical time is greater than 0.54+0.562=1.12ms, that is, 
                #the period is greater than the logical 0 period, that is equivalent to receiving logical 1
                if count > 8:   
                    data[idx] |= 1<<cnt    #When idx=0 is the first data  data[idx] = data[idx] | 1<<cnt   00000001 <<1 == 0000 0010
                if cnt == 7:    #With 8 byte
                    cnt = 0     #Displacement qing 0
                    idx += 1    #Store the next data
                else:
                    cnt += 1   #The shift adds 1
            #Determine whether address code + address inverse code =0xff, control code + control inverse code = 0xFF
            if data[0]+data[1] == 0xFF and data[2]+data[3] == 0xFF:  
                print("Get the key: 0x%02x" %data[2])  #Data [2] is the control code we need
                exec_cmd(data[2])
                 
                if(data[2] == 0x44):
                    forward()
                    print("motor run")
                if(data[2] == 0x43):
                    back()
                    print("motor back")
                if(data[2] == 0x40):
                    stop()
                    print("motor stop")
                if(data[2] == 0x46):
                    speed = speed + 10
                    if(speed >= 100):
                        speed = 99
                    print("speed add 10")
                if(data[2] == 0x15):
                    speed = speed - 10
                    if(speed <= 50):
                        speed = 50
                    print("speed subtract 10")

                if(data[2] == 0x16):
                    setColor(100,0,0)
                if(data[2] == 0x19):
                    setColor(0,100,0)
                if(data[2] == 0x0d):
                    setColor(0,0,100)
                if(data[2] == 0x0c):
                    setColor(100,100,0)
                if(data[2] == 0x18):
                    setColor(0,100,100)
                if(data[2] == 0x5e):
                    setColor(100,100,100)
                if(data[2] == 0x1c):
                    setColor(0,0,0)

                if(data[2] == 0x08):
                    GPIO.output(relayPin,GPIO.HIGH)  #Starting relay
                if(data[2] == 0x5a):
                    GPIO.output(relayPin,GPIO.LOW)
                if(data[2] == 0x42):
                    p.ChangeDutyCycle(0)
                    angle = angle + 10
                    if(angle >= 180):
                        angle = 180
                    c = map(angle, 0, 180, servo_min_angle, servo_max_angle)  #map angle from 0~180 to 2.5~12.5
                    p.ChangeDutyCycle(c) 
                    time.sleep(0.01)
                if(data[2] == 0x4a):
                    p.ChangeDutyCycle(0)
                    angle = angle - 10
                    if(angle <= 0):
                        angle = 0
                    c = map(angle, 0, 180, servo_min_angle, servo_max_angle)  #map angle from 0~180 to 2.5~12.5
                    p.ChangeDutyCycle(c) 
                    time.sleep(0.01)
except KeyboardInterrupt:
    GPIO.cleanup()
