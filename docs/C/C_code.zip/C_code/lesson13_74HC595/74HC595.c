#include <wiringPi.h>
#include <wiringShift.h>
int dataPin = 0; //define three pins  BCM GPIO 17
int latchPin = 2; //BCM GPIO 22
int clockPin = 3; //BCM GPIO 27
int a[10]={252,96,218,242,102,182,190,224,254,246}; 
int x;
int main()
{
  wiringPiSetup();
 
  {
  pinMode(latchPin,OUTPUT);
  pinMode(clockPin,OUTPUT);
  pinMode(dataPin,OUTPUT); //three pins as output
  }
  
  while(1)
  { 
  for(x=0; x<10 ;x++ )                        //calculate counting function
  {
    digitalWrite(latchPin,LOW);
    shiftOut(dataPin,clockPin,MSBFIRST,a[x]);     //display array a[x]
    digitalWrite(latchPin,HIGH);
    delay(1000);
  }
  }	
}
