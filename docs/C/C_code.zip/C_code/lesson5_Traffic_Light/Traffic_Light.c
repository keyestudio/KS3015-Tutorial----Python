#include <wiringPi.h>

#define R_pin 1  //BCM GPIO 18
#define G_pin 4  //BCM GPIO 24
#define Y_pin 5  //BCM GPIO 23

int main()
{
  wiringPiSetup();
  char j;
  pinMode(R_pin,OUTPUT);
  pinMode(G_pin,OUTPUT);
  pinMode(Y_pin,OUTPUT);
  
  digitalWrite(R_pin, LOW);
  digitalWrite(G_pin, LOW);
  digitalWrite(Y_pin, LOW);
  
  while(1)
  { 
   digitalWrite(R_pin, HIGH);//// turn on red LED
   delay(5000);// wait 5 seconds
   digitalWrite(R_pin, LOW); // turn off red LED
   for(j=0;j<3;j++) // blinks for 3 times
   {
   digitalWrite(G_pin, HIGH);// turn on yellow LED
   delay(500);// wait 0.5 second
   digitalWrite(G_pin, LOW);// turn off yellow LED
   delay(500);// wait 0.5 second
   } 

   digitalWrite(Y_pin, HIGH);// turn on green LED
   delay(5000);// wait 5 second
   digitalWrite(Y_pin, LOW);// turn off green LED
   } 
}
