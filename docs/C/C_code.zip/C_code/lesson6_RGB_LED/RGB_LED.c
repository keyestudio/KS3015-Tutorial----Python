 #include <stdio.h>
 #include <stdlib.h>
 #include <stdint.h>
 #include <wiringPi.h>
 #include <softPwm.h>
 #include <time.h>

 #define pin_R 5 //BCM GPIO 24
 #define pin_G 4 //BCM GPIO 23
 #define pin_B 1 //BCM GPIO 18
 

int main(void){
     int red,green,blue;
     if (wiringPiSetup() == -1){
          printf("Setup GPIO error!\n");
          return -1;
     }
     softPwmCreate(pin_R, 0, 100); 
     softPwmCreate(pin_G, 0, 100); 
     softPwmCreate(pin_B, 0, 100); 
     
     while (1){
          srand((unsigned)time(NULL));
          red = rand()%101 + 0;
          green = rand()%101 + 0;
          blue = rand()%101 + 0;
          softPwmWrite(pin_R, red);
          softPwmWrite(pin_G, green);
          softPwmWrite(pin_B, blue);
          delay(100);
     }
     return 0;
}
