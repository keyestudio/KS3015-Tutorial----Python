#include <stdio.h>
#include <wiringPi.h>
 
#define LED 1  //define led pin

int main(void)
{
    int bright;
    printf("Raspberry Pi wiringPi PWM test program\n");
    wiringPiSetup();  //Initialize wiringPi
    pinMode(LED,PWM_OUTPUT);  //set the ledPin OUTPUT mode
    
    while(1)
    {
        for (bright = 0; bright < 1024; ++bright)   // pwm 0~1024
        {
            pwmWrite(LED,bright);
            printf("bright:%d\n",bright);  //%d is the integer output, bright is the variable to output
            delay(10);
        }
        for (bright = 1023; bright >= 0; --bright)
        {
            pwmWrite(LED,bright);
            printf("bright:%d\n",bright);
            delay(10);
        }
    }
    return 0;
 }
