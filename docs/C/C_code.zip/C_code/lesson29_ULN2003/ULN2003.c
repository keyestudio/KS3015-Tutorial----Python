#include <wiringPi.h>
int IN1 = 3;  //BCM GPIO 22
int IN2 = 2;  //BCM GPIO 27
int IN3 = 0;  //BCM GPIO 17
int IN4 = 7;  //BCM GPIO 4
void set_step(int a,int b,int c,int d)
{
 digitalWrite(IN1,a);
 digitalWrite(IN2,b);
 digitalWrite(IN3,c);
 digitalWrite(IN4,d);
}
int main()
{
  wiringPiSetup();
 
  {
  pinMode(IN1,OUTPUT);
  pinMode(IN2,OUTPUT);
  pinMode(IN3,OUTPUT); 
  pinMode(IN4,OUTPUT); 
  }
  
  while(1)
  { 
     //One cycle, four beats, four steps, so 2048/4 = 512 cycles to make one rotation
     int x = 512;
     int y = 512;
     while(x--) //Counterclockwise rotation
     {
         set_step(0,0,0,1);
         delay(3);
         set_step(0,0,1,0);
         delay(3);
         set_step(0,1,0,0);
         delay(3);
         set_step(1,0,0,0);
         delay(3);
     }
     set_step(0,0,0,0);
     delay(3000);
     while(y--)  //Clockwise rotation
     {
         set_step(1,0,0,0);
         delay(3);
         set_step(0,1,0,0);
         delay(3);
         set_step(0,0,1,0);
         delay(3);
         set_step(0,0,0,1);
         delay(3);
     }
     set_step(0,0,0,0);
     delay(3000);
  }	
}
