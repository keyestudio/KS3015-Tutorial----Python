#include "Keypad.hpp"
#include <stdio.h>
#include <cstring>

#define serPin 1 //servo pin
char key_rec[50];
char password[] = "123D";
char Enter[] = "D";
int i = 0;
const byte ROWS = 4; //four rows
const byte COLS = 4; //four columns
char keys[ROWS][COLS] = {  //key code
  {'1','2','3','A'},
  {'4','5','6','B'},
  {'7','8','9','C'},
  {'*','0','#','D'}
};
byte rowPins[ROWS] = {26,27,28,29}; //define the row pins for the keypad
byte colPins[COLS] = {22,23,24,25 }; //define the column pins for the keypad
//create Keypad object
Keypad keypad = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

int main(){
    printf("Program is starting ... \n");
    
    wiringPiSetup();
    
    pinMode(serPin,OUTPUT);  //set servo pin OUTPUT
	char key = 0;
	keypad.setDebounceTime(50);
    while(1){
        key = keypad.getKey();  //get the state of keys
        if (key){       //if a key is pressed, print out its key code
            //printf("You Pressed key :  %d \n",key);
            key_rec[i] = key;
            printf("passward = %s\n",key_rec);
            i++;
            
            if(key == 68)   //The ASCII value of character D is 68
            {
                if(strcmp(key_rec, password) == 0)
                {
                    printf("open the door\n");
                    for(i=0;i<50;i++)   //servo
                    {
                        digitalWrite(serPin,HIGH);
                        delayMicroseconds(2500); //Pulse width 0.5ms, Angle 0
                        digitalWrite(serPin,LOW);
                        delay(20-0.5);	//Cycle 20 ms
                    }
                }
                else
                {
                    printf("error\n");
                    for(i=0;i<50;i++)   //servo         
                    {
                        digitalWrite(serPin,HIGH);
                        delayMicroseconds(500); //Pulse width 0.5ms, Angle 0
                        digitalWrite(serPin,LOW);
                        delay(20-0.5);	//Cycle 20 ms
                    }
                }
                for(int c=0; c<i; c++)
                {
                    key_rec[c] = 0;  //clean key_rec[]
                }
                i = 0;
            }
        }
    }
    return 1;
}

