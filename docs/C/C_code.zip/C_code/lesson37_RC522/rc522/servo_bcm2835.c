#include <bcm2835.h>

#define  serPin   RPI_GPIO_P1_12   //set  servo  pin (BCM GPIO18)

int main()
{
	if(!bcm2835_init())  //bcm 2835 init
	{
		return 1;
	}
	bcm2835_gpio_fsel(serPin, BCM2835_GPIO_FSEL_OUTP);  //set servo pin OUTPUT mode
	
	while(1)
	{
		for(int i=0;i<50;i++)            
		{
			bcm2835_gpio_write(serPin, HIGH);  //set servo pin HIGH
			bcm2835_delayMicroseconds(500);    //delay 500us
			bcm2835_gpio_write(serPin, LOW);   //set servo pin LOW
			bcm2835_delay(19.5);  //delay 20 - 0.5 = 19.5ms
		}
		bcm2835_delay(1000); //delay 1s
		for(int i=0;i<50;i++)            
		{
			bcm2835_gpio_write(serPin, HIGH);
			bcm2835_delayMicroseconds(2500);   //delay 2500us
			bcm2835_gpio_write(serPin, LOW);
			bcm2835_delay(17.5);  //delay 20 - 2.5 = 17.5ms
		}
		bcm2835_delay(1000); //delay 1s
	}
	
	bcm2835_close();  //close bcm2835
	return 0;
}
