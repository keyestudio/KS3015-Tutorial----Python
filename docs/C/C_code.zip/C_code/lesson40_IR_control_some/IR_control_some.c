#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wiringPi.h>
#include <math.h>
#include <softPwm.h>

#define PIN 5  //ir pin  BCM GPIO 24
#define IO digitalRead(PIN)
unsigned char i,idx,cnt;
unsigned char count;
unsigned char data[4];

//define L293D pin
#define INA1 0  //BCM GPIO 17
#define INA2 2  //BCM GPIO 20
#define ENA  3  //BCM GPIO 22
int speed = 50;

//define RGB pin
#define R_pin 29  //BCM GPIO 21
#define G_pin 28  //BCM GPIO 20
#define B_pin 27  //BCM GPIO 16

#define relay_pin 26  //BCM GPIO 12

#define servo_pin 25  //BCM GPIO 26
int angle = 1500;

//motor forward
void motor_forward()
{
	digitalWrite(INA1,LOW);
	digitalWrite(INA2,HIGH);
	softPwmWrite(ENA,speed);
}
//motor reverse
void motor_reverse()
{
	digitalWrite(INA1,HIGH);
	digitalWrite(INA2,LOW);
	softPwmWrite(ENA,speed);
}
//motor stop
void motor_stop()
{
	digitalWrite(INA1,LOW);
	digitalWrite(INA2,LOW);
	softPwmWrite(ENA,0);
}
//Increase the speed
void speed_add()
{
	speed = speed + 10;
	if(speed >= 100)
	{
		speed = 100;
	}
}
//Reduce speed
void speed_sub()
{
	speed = speed - 10;
	if(speed <= 0)
	{
		speed = 0;
	}
}
//Set the color of the RGB lamp
void rgb(int rVal, int gVal, int bVal)
{
	softPwmWrite(R_pin,rVal);
	softPwmWrite(G_pin,gVal);
	softPwmWrite(B_pin,bVal);
}
//Set the steering gear Angle
void set_servo(int angle_val)
{
	angle = angle + angle_val;
	printf("angle = %d", angle);
	if(angle >= 2500)
	{
		angle = 2500;
	}
	if(angle <= 500)
	{
		angle = 500;
	}
	for(i=0;i<50;i++)            
	{
		digitalWrite(servo_pin,HIGH);
		delayMicroseconds(angle);
		digitalWrite(servo_pin,LOW);
		delay(20-(angle*0.001));
	}
}

//The main function, the program starts here
int main()
{
    if (wiringPiSetup() < 0)return 1;  //Determines if wiringPi is initialized
    //Set the state of the individual pins
    pinMode(PIN, INPUT);
    pullUpDnControl(PIN, PUD_UP);
	printf("IRM Test Program ... \n");
	pinMode(INA1, OUTPUT);
	pinMode(INA2, OUTPUT);
	softPwmCreate(ENA, 0, 100);  //motor pwm
	
	softPwmCreate(R_pin, 0, 100);
	softPwmCreate(G_pin, 0, 100);
	softPwmCreate(B_pin, 0, 100);
	
	pinMode(relay_pin, OUTPUT);
	
	pinMode(servo_pin, OUTPUT);
	set_servo(0);
	delay(300);

	while (1)  //The main loop
	{	
		if(IO == 0)
		{
			count = 0;
			while(IO == 0 && count++ < 200)   //9ms
		    	delayMicroseconds(60);
			
			count = 0;
			while(IO == 1 && count++ < 80)	  //4.5ms
		    	delayMicroseconds(60);
			
			idx = 0;
			cnt = 0;
			data[0]=0;
			data[1]=0;
			data[2]=0;
			data[3]=0;
			for(i =0;i<32;i++)
			{
				count = 0;
				while(IO == 0 && count++ < 15)  //0.56ms
		    		delayMicroseconds(60);
				
				count = 0;
				while(IO == 1 && count++ < 40)  //0: 0.56ms; 1: 1.69ms
		    		delayMicroseconds(60);

				if (count > 25)data[idx] |= (1<<cnt);
				if(cnt == 7)
				{
					cnt = 0;
					idx++;
				}
				else cnt++;
			}

			if(data[0]+data[1] == 0xFF && data[2]+data[3]==0xFF)	//check	
			{
				printf("Get the key: 0x%02x\n",data[2]);
				switch(data[2])
				{
					case 0x44: motor_forward(); break;
					case 0x43: motor_reverse(); break;
					case 0x40: motor_stop(); break;
					case 0x46: speed_add(); break;
					case 0x15: speed_sub(); break;
					
					case 0x16: rgb(100, 0, 0); break;
					case 0x19: rgb(0, 100, 0); break;
					case 0x0d: rgb(0, 0, 100); break;
					case 0x0c: rgb(1024, 100, 0); break;
					case 0x18: rgb(0, 100, 100); break;
					case 0x5e: rgb(100, 100, 100); break;
					case 0x1c: rgb(0, 0, 0); break;
					
					case 0x08: digitalWrite(relay_pin, HIGH); break;
					case 0x5a: digitalWrite(relay_pin, LOW); break;
					
					case 0x42: set_servo(150); break;
					case 0x4a: set_servo(-150); break;
				}
			}
				
		}
	}
}
