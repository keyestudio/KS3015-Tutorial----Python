#include <wiringPi.h>   //wiringPi GPIO library
#include <stdio.h>  //standard input & output library

int main()  //Main function, the entry of the program
{
  
  wiringPiSetup();  //Initializes the wiringPi GPIO library
  while(1)  //An infinite loop
  {
    printf("Hello World!\n");  //\n is a newline print
    delay(1000);  //delay 1000ms
  }
}
