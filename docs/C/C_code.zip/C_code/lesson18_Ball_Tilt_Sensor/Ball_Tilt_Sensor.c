 #include <stdio.h>
 #include <stdlib.h>
 #include <stdint.h>
 #include <wiringPi.h>
 #include <softPwm.h>

//define led pin
 #define LED1 0  //BCM GPIO 17
 #define LED2 2  //BCM GPIO 27
 //define Ball Tilt Sensor Pin
 #define tiltPin 1  //BCM GPIO 18

 int main(void){
     int val;
     int val1 = 50;  //Initial value of LED brightness
     int val2 = 50;
     if (wiringPiSetup() == -1)
     {
        printf("Setup GPIO error!\n");
        return -1;
     }
     softPwmCreate(LED1, 0, 100);  //Define the pin as PWM output
     softPwmCreate(LED2, 0, 100); 
     while (1)
     {
        val=digitalRead(tiltPin); //Read the value of the tilt sensor
        if(val==0)  //upright
        {
          val1++;  //The value of LED1 increases
          val2--;  //Led2 value reduced
          if(val1>=100)  //The size of the limit
          {
            val1 = 100;
          }
          if(val2<=0) //The size of the limit
          {
            val2 = 0;
          }
          softPwmWrite(LED1, val1);  //The value after PWM output changes
          softPwmWrite(LED2, val2);
          delay(50);  //Delay, adjust the speed
        }
        else
        {
          val1--;
          val2++;
          if(val1<=0)
          {
            val1 = 0;
          }
          if(val2>=100)
          {
            val2 = 100;
          }
          softPwmWrite(LED1, val1);
          softPwmWrite(LED2, val2);
          delay(50);
        }
     }
  return 0;
}
