/******
Demo for ssd1306 i2c driver for  Raspberry Pi 
******/

#include "ssd1306_i2c.h"

int x = 30;

void main() {
	ssd1306_begin(SSD1306_SWITCHCAPVCC, SSD1306_I2C_ADDRESS);   //Initialize the OLED
	
	while(1)
	{
		ssd1306_clearDisplay();   //Clear the screen
		ssd1306_setTextSize(1);  //Define font size
		char* text = "This is demo for SSD1306 i2c driver for Raspberry Pi";
		ssd1306_drawString(text);  //load string
		ssd1306_display();  //display
		delay(1000);
		

		ssd1306_dim(1);  //Whether or not the display is fuzzy
		ssd1306_startscrollright(00,0xFF);  //Scroll to the right
		delay(1000);
		ssd1306_stopscroll();  //stop scroll

		ssd1306_clearDisplay();
		char c[] = "keyes";
		for(int i=0; i<5; i++)  //Five characters
		{
			ssd1306_drawChar(x, 20, c[i], WHITE, 1);  //Specifies the coordinate display character
			x = x + 6; //When the font size is 1, the font pixel is 6*8
		}
		//ssd1306_drawChar(30, 20, c[1], WHITE, 1);  //Specifies the coordinate display character
		ssd1306_display();  //display
		delay(3000);

		ssd1306_clearDisplay();
		ssd1306_fillRect(10,10, 50, 20, WHITE); //Draw a fill rectangle
		ssd1306_fillRect(80, 10, 130, 50, WHITE);
		ssd1306_display();
		delay(5000);
	}
	
}
