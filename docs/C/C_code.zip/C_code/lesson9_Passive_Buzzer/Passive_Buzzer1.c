#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <wiringPi.h>

#define buzPin 1  //BCM GPIO 18

void init()
{
   if (wiringPiSetup () == -1)
       exit (1) ;
   pinMode(buzPin, PWM_OUTPUT); //Set the pin to PWM output mode
   pwmSetMode(PWM_MODE_MS);  // Set PWM signal mode to MS mode
   pwmSetClock(32);  // Set the clock base frequency to 19.2m /32=600KHZ
}

void beep(int freq,int t_ms)
{
   int range;
   if(freq<100||freq>1000)
   {
      printf("invalid freq");
      return;
   }
   // Set the range to 600KHZ/ Freq. That is, 
   //the freQ frequency period is composed of the range of 1/600khz.
   range=600000/freq;
   pwmSetRange(range);
   pwmWrite(buzPin,range/2);  // Set the duty cycle to 50%.
   if(t_ms>0)
   {
      delay(t_ms);
   }
}

int main()
{
   wiringPiSetup();
   init();

   while(1)
   { 
      beep(262,300);  //Frequency and time
      printf("do\n");
      beep(294,300);
      printf("re\n");
      beep(330,300);
      printf("mi\n");
      beep(349,300);
      printf("fa\n");
      beep(392,300);
      printf("so\n");
      beep(440,300);
      printf("la\n");
      beep(494,300);
      printf("si\n");
      beep(523,300);
      printf("Do\n");
      pwmWrite(buzPin,0);   //turn off the buzzer 
      delay(2000);  
   } 	  
}

