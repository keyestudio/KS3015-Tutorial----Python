#include <wiringPi.h>

int y[8]={2,7,21,0,25,22,24,23};  //Y direction pin
int x[8]={5,27,28,1,29,4,6,26};   //X direction pin

int main()
{
  wiringPiSetup();
  char i;
  char j;
  for(i=0;i<8;i++)  //Set both XY pins to output mode
  {
    pinMode(y[i],OUTPUT);
    pinMode(x[i],OUTPUT);
  }

  while(1)
  {
     for(j=0;j<8;j++)
    {
       digitalWrite(x[j], LOW);// set I/O pins as low
    }  
    for(i=0;i<8;i++)
    {
       digitalWrite(y[i], HIGH);// set I/O pins as high
        delay(200);       // delay
    }
     for(i=0;i<8;i++)
    {
       digitalWrite(y[i], LOW);// set I/O pins as low
        delay(200);       // delay
    }
  }    
}
